<?php

// THIS PHP CODE, THE STYLE SHEET, AND ALL ASSOCIATED GRAPHICAL
// ELEMENTS ARE (C) FORECA, BUT THEY CAN BE FREELY USED WHEN
// VISUALIZING FORECA DATA.

// Requires PHP5+ with SimpleXML module (enabled by default)

// Fill in the BASEURL and FORMAT provided to you by Foreca
define("NAVIBASEURL", "http://FILL-IN-NAVIFEED-HOST/");
define("FORMAT",      "FILL-IN-NAVIFEED-FORMAT");
define("NAMEBASEURL", "http://FILL-IN-NAMEFEED-HOST/FILL-IN-NAMEFEED-FORMAT/");

// Load English translations of weather codes, warning codes and ui
require_once("lang/weather_en.inc");
require_once("lang/f0_en.inc");
require_once("lang/fs0_en.inc");
require_once("lang/f1_event_en.inc");
require_once("lang/foreca_weather_en.inc");

// Suggested default units for some parts of the world, temp/wind speed:
//   Northern Europe: C/MS
//   Southern Europe: C/KMH
//   Imperial:        C/MPH
//   US:              F/MPH
$tempunit = "C";  // C|F
$windunit = "MS"; // MS|KMH|KTS|MPH

// Country of user - affects visualization, e.g., picking symbol for wildfire
$country = "fi";

// Expand the MySQL style src date year, month, etc. components to
// dest array
function explodeDate($src, &$dest) {
  if(strlen($src) > 12)
    list($dest["date"], $dest["time"]) = explode(" ", $src);
  else
    $dest["date"] = $src;

  list($dest["year"], $dest["month"], $dest["day"]) = explode("-", $dest["date"]);
  $dest["prettydate"] = $dest["month"] . "/" . $dest["day"];
  $dest["weekday"] = date( "l", mktime(0, 0, 0, $dest["month"]  , $dest["day"], $dest["year"]) );
  $dest["weekdayShort"] = date( "D", mktime(0, 0, 0, $dest["month"]  , $dest["day"], $dest["year"]) );
  if(!empty($dest["time"])) {
     list($dest["hour"], $dest["min"],   $dest["sec"]) = explode(":", $dest["time"]);
     $dest["prettytime"] = $dest["hour"] . ":" . $dest["min"];
  }
}


// Create the base URL for getting weather based on coords,
// unit conversions appended later
function getWeatherURLWithLonLat($lon, $lat) {
  return NAVIBASEURL . 'showdata.php?ftimes=72/24h&format=' . FORMAT 
    . '&lon=' . $_GET["lon"] . '&lat=' . $_GET["lat"];
}


// Create the base URL for getting weather based on Foreca IDs,
// unit conversions appended later
function getWeatherURLWithID($id) {
  return NAMEBASEURL . 'data.php?l=' . $id;
}


// Query the URL and parse result into the obs, fc and wr arrays
function getForecaWeatherXML(&$obs, &$fc, &$wr, $url) {
  global $tempunit, $windunit;

  $tu = "";
  if($tempunit !== "C") {
    $tu = '&tempunit=' . $tempunit;
  }
  
  $wu = "";
  if($windunit !== "MS") {
    $wu = '&windunit=' . $windunit;
  }

  $query = $url . $tu . $wu;
  if(count(file($query)) < 6) {
    return 0;
  }
  
  $xmldoc = simplexml_load_file($query);
  if($xmldoc === false) {
    return 0;
  }
  
  // Find starting point for parsing weather data (the structure of the xml document may vary depending on the feed)
  $xml = NULL;
  if(isset($xmldoc->loc->fc)) {
    $xml = $xmldoc->loc;
  }
  else if(isset($xmldoc->weather->fc)) {
    $xml = $xmldoc->weather;
  }
  else {
    return 0;
  }

  // Any combination of obs data can be missing - check for minimum interesting data:
  // Station name and obs date should _always_ be there, temperature is the only required weather item
  if(!(isset($xml->obs["station"]) && isset($xml->obs["dt"]) && isset($xml->obs["t"]))) {
    $obs = "";
  }
  // Parse observation data
  else {
    foreach($xml->obs[0]->attributes() as $k => $v) {
      $obs[$k] = (string) $v;
    }
    explodeDate($obs["dt"], $obs);
  }
  
  // See if forecast data is missing
  if(!isset($xml->fc)) {
    $fc = null;
    return 0;
  }
  // Parse forecast data
  else {
    $i = 0;
    foreach($xml->fc as $fcs) {
      foreach($fcs->attributes() as $k => $v) {
        $fc[$i][$k] = (string) $v;
      }
      
      // Require that date and time are specified
      if(isset($fc[$i]) && isset($fc[$i]["dt"]) && $fc[$i]["dt"] !== "") {
        explodeDate($fc[$i]["dt"], $fc[$i]);
      }
      else {
        $fc[$i] = null;
        return 0;
      }
      
      $i++;
    }
  }
  
  // Parse warning data (if available - depends on the features of the feed in use)
  $wr = array();
  $i = 0;
  foreach($xml->w as $w) {
    foreach($w->attributes() as $k => $v) {
      $wr[$i][$k] = (string) $v;
    }
    
    // Expand times
    foreach(array("dtfrom", "dtuntil", "dtfromu", "dtuntilu") as $v) {
      if(isset($wr[$i][$v]) && $wr[$i][$v] !== "") {
        $key = $v . "_pretty";
        $wr[$i][$key] = array();
        explodeDate($wr[$i][$v], $wr[$i][$key]);
      }
    }
    
    // Parse content of <text> tags, include all available translations
    $j = 0;
    foreach($w->text as $t) {
      if(isset($t["lang"])) {
        $langId = (string) $t["lang"];
      }
      else {
        $langId = $j;
        $j++;
      }
      $wr[$i]["text"][$langId] = (string) $t;
    }
    
    $i++;
  }

  return 1;
}


// meters to miles
function m2mi($m) {
  if(!is_numeric($m)) {
    return FALSE;
  }
  return 0.000621371192 * $m;
}


// Prepend positive Celsius temps with +, append unit,
// different color below/above freezing
function temperature2HTML($temp, $large) {
  global $tempunit;

  // Different color above/below freezing
  $style = "";
  $ctemp = $temp;
  if($tempunit === "F")
    $ctemp = ($temp - 32)/1.8;
  if($large) {
    if($ctemp>=0)
      $style = "warm txt-xxlarge";
    else
      $style = "cold txt-xxlarge";
  }
  
  // Prepend positive Celsius with "+", add formatting
  if($temp > 0 && $tempunit == "C")
    $temp = "<span class='$style'><strong>+" . $temp . "</strong>";
  else if($temp >= 0 && $tempunit == "C")
    $temp = "<span class='$style'><strong>" . $temp . "</strong>";
  else 
    $temp = "<span class='$style'><strong>" . $temp . "</strong>";
  return $temp . "&nbsp;&deg;$tempunit</span>";
}


// Append units, fix colors, and do other similar formatting for
// weather parameters. Add empty string for missing params.
// See http://corporate.foreca.com/en/NaviFeed for param documentation.
function weather2HTML(&$weather, $large) {
  global $tempunit, $windunit, $windunit_str, $symbol_str, $ui;

  $symsize="50x50";
  if($large)
    $symsize = "70x70";

  // General params we wish to set empty, if they do not exist
  $parray = array("prettytime", "prettydate", "weekday", "station");
  foreach( $parray as $param ) {
    if(!isset($weather[$param]))
      $weather[$param] = "";
  }

  // all the various temps
  $temptype = array("t", "tf", "tn", "tx", "ta"); // temp, feels-like, min, max, average
  foreach( $temptype as $ttype ) {
    if(isset($weather[$ttype]) and $weather[$ttype] !== "") {
      $weather[$ttype] = temperature2HTML($weather[$ttype], $large);
    } else {
      $weather[$ttype] = "";
    }
  }

  // weather symbol
  if(!empty($weather['s'])) {
    $symclass = "";
    if($large)
      $symclass = "class='symb'";
    $sym = substr($weather['s'], 1);
    $symstr = "weather symbol";
    if(isset($symbol_str[$sym]))
      $symstr = $symbol_str[$sym];
    $weather['s'] = "<img $symclass src='img/symb-$symsize/" . $weather['s'] . ".png' alt='$symstr' title='$symstr' />";
    if(empty($weather['sT']))
      $weather['sT'] = $symstr;
  } else {
    $symclass = "";
    $weather['s'] = "<img $symclass src=\"img/transpixel.gif\" alt=\"$ui[err_missing_weather_code]\" height=\"70\" width=\"70\" align=\"left\" />";
  }

  // wind speed
  if(isset($weather['ws']) and $weather['ws'] !== "") {
    $weather['ws'] = $weather['ws'] . "&nbsp;" . $windunit_str[$windunit];
  } else {
    $weather['ws'] = "";
  }
  
  // wind direction
  if(!empty($weather['wn'])) {
    $weather['wn'] = "<img src='img/wind/" . $weather['wn'] . ".png' alt='" . $weather['wn'] . "' />";
  } else {
    $weather['wn'] = "";
  }
  
  // "distance to observation station" string
  if(!empty($weather['dist'])) {
    $weather['dist'] = $weather['dist'] . " of given coords"; //" . $_GET['lon'] . "," . $_GET['lat'];
  } else {
    $weather['dist'] = "";
  }
  
  // visibility
  if(!empty($weather['v'])) {
    if($windunit == "MPH" ||  $windunit == "KTS")
      $weather['v'] = m2mi($weather['v']) . "&nbsp;miles";
    else {
      if($weather['v'] >= 1000)
        $weather['v'] = round($weather['v']/1000) . "&nbsp;km";
      else
        $weather['v'] .= "&nbsp;m";
    }
  } else {
    $weather['v'] = "";
  }
}

// Returns an HTML snippet for displaying a warning
function warning2HTML($w) {
  global $f0, $fs0, $f1_event, $country, $ui;
  
  // compose path for warning symbol
  
  $src = "img/wsymb-40x35/";
  
  // pick symbol according to the f0 code ("Foreca class") minding a few special cases
  if(array_key_exists($w["f0"], $f0)) {
    $f1Cyclone = array(119, 124, 125, 142, 144, 
                       177, 182, 183, 200, 202,
                       235, 240, 241, 258, 260,
                       315, 316, 317,
                       327, 328, 329,
                       375, 376, 377,
                       406, 407, 408,
                       512, 513, 514,
                       663, 674, 685);
    $f1Tornado = array(141, 199, 257,
                       403, 404, 405,
                       439, 440, 441);
    $f0FDSpruce = array("fi", "se", "no", "is", "ca", "ru");
                       
    // special case: tropical cyclone (e.g. hurricane)
    if(in_array(intval($w["f1"]), $f1Cyclone)) {
      $src .= "cy";
    }
    // special case: tornado
    else if(in_array(intval($w["f1"]), $f1Tornado)) {
      $src .= "to";
    }
    // special case: fire danger in an area where spruces grow commonly (and thus are a natural symbol for a tree)
    else if(strcmp($w["f0"], "FD") == 0 && in_array($country, $f0FDSpruce)) {
      $src .= "fd_spruce";
    }
    else {       
      $src .= strtolower($w["f0"]);
    }
  }
  else {
    $src .= "ot";
  }
  
  if(array_key_exists($w["fs0"], $fs0)) {
    $src .= "_" . strtolower($w["fs0"]) . ".png";
  }
  else {
    // if significance of warning is unknown, use Orange
    $src .= "_o.png";
  }

  // compose alt text for warning symbol

  $alt = "";

  // name of event
  $eventEn = $f0["OT"]; // general/unknown warning
  if(isset($f1_event[$w["f1"]])) {
    $eventEn = $f1_event[intval($w["f1"])];
  }
  
  // time of validity
  $dtValid = "";
  // ignore if f1 means ok, not covered, not available
  if(!in_array($w["f1"], array("88", "89", "90"))) { 
    $dtValid = " (" . $ui["err_unknown_validity"] . ").";
    if(isset($w["dtfrom_pretty"]) && isset($w["dtuntil_pretty"])) {
      $dtValid = " (" . $w["dtfrom_pretty"]["weekdayShort"] . " " . $w["dtfrom_pretty"]["prettydate"] . " " . $w["dtfrom_pretty"]["prettytime"] . " ... " .
                 $w["dtuntil_pretty"]["weekdayShort"] . " " . $w["dtuntil_pretty"]["prettydate"] . " " . $w["dtuntil_pretty"]["prettytime"] . ").";
    }
  }
  
  // description text - if preferred language is not available, use combination of all available languages
  $text = ""; 
  $lang = isset($_GET["lang"]) ? $_GET["lang"] : "";
  if(isset($w["text"]) && is_array($w["text"])) {
    if(isset($w["text"][$lang])) {
      $text = $w["text"][$lang];
    }
    else {
      $text = implode(" / ", $w["text"]);
      $text = " $text";
    }
  }
  
  // attribution
  $attr = (isset($w["attr"]) && $w["attr"] != "") ? " [" . $w["attr"] . "]" : "";
  
  $alt = $eventEn . $dtValid . $text . $attr;
  
  return "<img src='$src' alt='$alt' title='$alt'/>";
}

// Demonstrate pretty html weather. For production we recommend using
// Smarty or some other template engine, but this demo was stripped to
// bare PHP for brevity.
function printWeatherPrettyHTML($obs, $fc, $wr) {
  global $f0, $fs0, $f1_event, $ui;

  $html = file_get_contents("tpl/weather.template");

  // Clean observation parameters so that they exist as empty strings or valid html
  weather2HTML($obs, 1);

  // Handle completely missing observations
  if($obs === "" || empty($obs['dt'])) {
    $ccstr = "<div style='margin-left:10;'>$ui[err_no_recent_obs].</div>";
  } else {
    $ccstr = "			<div class=\"left\">
					{OBSs} {OBSt}<br />
					{OBSwn} <strong>{OBSws}</strong><br />
				</div>
                 		<div class=\"bot txt-tight grey\">
					$ui[observation_time] {OBSprettytime} {OBSweekday}<br />$ui[observed_at] {OBSstation}<br />{OBSdist}
				</div>";
  }

  // Create perl regexp rules for replacing weather param tags in html template
  $i = 0;
  $patterns[$i] = "/{CURRENT_CONDITIONS}/"; $replacements[$i++] = $ccstr;

  foreach( array_keys($obs) as $obsparam ) {
    $patterns[$i] = "/{OBS$obsparam}/"; $replacements[$i++] = $obs[$obsparam];
  }

  // Loop through all forecast time steps and process the same way as observations above
  for( $j=0; $j<3; $j++ ) {
    weather2HTML($fc[$j], 0);
    foreach( array_keys($fc[$j]) as $fcparam ) {
      $patterns[$i] = "/{FC$j$fcparam}/"; $replacements[$i] = $fc[$j][$fcparam];
      $i++;
    }
  }
  
  // Process warnings
  $dispWarnings = "none";
  $wSymbArr = array();
  foreach($wr as $w) {
    // Foreca visualization suggestion: if everything is ok, skip visualization,
    // i.e., handle non-critical information unobtrusively
    if(strcmp($w["f0"], "OK") == 0) {
      continue;
    }
    
    $wSymbArr[] = warning2HTML($w);  
    $dispWarnings = "block";
  }
  $patterns[$i] = "/{dispWarnings}/";
  $replacements[$i++] = $dispWarnings;
  $patterns[$i] = "/{WARNINGS}/";
  $replacements[$i++] = implode("\r\n", $wSymbArr);

  $patterns[$i] = "/{LINKBACK}/"; 
  $replacements[$i++] = "http://www.foreca.com/?lon=" . $_GET["lon"] . "&lat=" . $_GET["lat"];

  $patterns[$i] = "/{LON}/"; $replacements[$i++] = $_GET["lon"];
  $patterns[$i] = "/{LAT}/"; $replacements[$i++] = $_GET["lat"];

  $patterns[$i] = "/{TITLE_WARNINGS}/"; $replacements[$i++] = $ui["warnings"];
  $patterns[$i] = "/{TITLE_CURRENT_CONDITIONS}/"; $replacements[$i++] = $ui["current_conditions"];
  $patterns[$i] = "/{TITLE_2_DAY_FORECAST}/"; $replacements[$i++] = $ui["daily_forecast_2"];
  $patterns[$i] = "/{GET_FULL_FORECAST}/"; $replacements[$i++] = $ui["get_full_forecast"];
  
  $html = preg_replace($patterns, $replacements, $html);
  echo $html;
}

####################################################

header("Content-Type: text/html;UTF-8");

$obs = "";
$fc = "";
$wr = "";
$url = "";

// Foreca NameFeed
if(isset($_GET["l"])) {
  $url = getWeatherURLWithID($_GET["l"]);
}

// Foreca NaviFeed
if(isset($_GET["lon"]) && isset($_GET["lat"])) {
  if($_GET["lon"]<-180 || $_GET["lon"]>180 || $_GET["lat"] < -90 || $_GET["lat"]>90) {
    echo "<html><body>$ui[err_coords_out_of_bounds].</body></html>";
    exit( 0 );
  }  
  $url = getWeatherURLWithLonLat($_GET["lon"], $_GET["lat"]);
}

if($url == "") {
  echo "<html><body>$ui[err_no_loc].</body></html>";
  exit( 0 );  
}

if(getForecaWeatherXML($obs, $fc, $wr, $url) == 0) {
  echo "<html><body>$ui[err_service_na].</body></html>";
  exit( 0 );
}

printWeatherPrettyHTML($obs, $fc, $wr);
?>
