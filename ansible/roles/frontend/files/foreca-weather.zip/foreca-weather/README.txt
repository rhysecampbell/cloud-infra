Modify weather.php by pasting your own Foreca-provided format parameter and base URLs as follows:

NaviFeed: modify NAVIBASEURL and FORMAT

NameFeed: modify NAMEBASEURL

The PHP wrapper is required since Foreca does not currently offer a public API.

Samu Karanko
Development Manager, 2008-11-11

THE PHP CODE, THE STYLE SHEET, AND ALL ASSOCIATED GRAPHICAL
ELEMENTS ARE (C) FORECA, BUT THEY CAN BE FREELY USED WHEN
VISUALIZING FORECA DATA.
